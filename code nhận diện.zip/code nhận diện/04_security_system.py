"""
MODULE 4: ANTI-DDOS + CHỐNG HACK + HIỆN IP XÂM NHẬP
Thư viện: pip install scapy psutil requests
Lưu ý: Cần chạy với quyền Administrator/root để bắt gói tin
"""

import socket
import threading
import time
import logging
import json
import os
import struct
import hashlib
import subprocess
import platform
from datetime import datetime, timedelta
from collections import defaultdict, deque
import ipaddress

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False
    print("[!] psutil chưa cài: pip install psutil")

logging.basicConfig(
    filename='security.log',
    level=logging.WARNING,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

WHITELIST_FILE = 'ip_whitelist.json'
BLACKLIST_FILE = 'ip_blacklist.json'
ALERT_LOG      = 'intrusion_alerts.log'

# ─────────────────────────────────────────────
# IP MANAGER (Whitelist / Blacklist)
# ─────────────────────────────────────────────
class IPManager:
    def __init__(self):
        self.whitelist = self._load(WHITELIST_FILE, ['127.0.0.1', '::1'])
        self.blacklist = self._load(BLACKLIST_FILE, [])
        self.block_duration = 3600  # giây

    def _load(self, path, default):
        if os.path.exists(path):
            with open(path) as f:
                return set(json.load(f))
        return set(default)

    def _save(self, path, data):
        with open(path, 'w') as f:
            json.dump(list(data), f, indent=2)

    def add_whitelist(self, ip):
        self.whitelist.add(ip)
        self._save(WHITELIST_FILE, self.whitelist)

    def block_ip(self, ip, reason=""):
        if ip in self.whitelist:
            return False
        self.blacklist.add(ip)
        self._save(BLACKLIST_FILE, self.blacklist)
        self._firewall_block(ip)
        logging.warning(f"BLOCKED: {ip} | Lý do: {reason}")
        print(f"[BLOCK] {ip} | {reason}")
        return True

    def unblock_ip(self, ip):
        self.blacklist.discard(ip)
        self._save(BLACKLIST_FILE, self.blacklist)
        self._firewall_unblock(ip)
        print(f"[UNBLOCK] {ip}")

    def is_blocked(self, ip):
        return ip in self.blacklist

    def _firewall_block(self, ip):
        """Chặn IP qua firewall hệ thống"""
        system = platform.system()
        try:
            if system == 'Windows':
                subprocess.run([
                    'netsh', 'advfirewall', 'firewall', 'add', 'rule',
                    f'name=BLOCK_{ip}', 'dir=in', 'action=block',
                    f'remoteip={ip}'
                ], capture_output=True)
            elif system in ('Linux', 'Darwin'):
                subprocess.run(['iptables', '-A', 'INPUT', '-s', ip, '-j', 'DROP'],
                               capture_output=True)
        except Exception as e:
            logging.error(f"Firewall block error: {e}")

    def _firewall_unblock(self, ip):
        system = platform.system()
        try:
            if system == 'Windows':
                subprocess.run([
                    'netsh', 'advfirewall', 'firewall', 'delete', 'rule',
                    f'name=BLOCK_{ip}'
                ], capture_output=True)
            elif system in ('Linux', 'Darwin'):
                subprocess.run(['iptables', '-D', 'INPUT', '-s', ip, '-j', 'DROP'],
                               capture_output=True)
        except Exception as e:
            logging.error(f"Firewall unblock error: {e}")


# ─────────────────────────────────────────────
# ANTI-DDOS ENGINE
# ─────────────────────────────────────────────
class AntiDDoS:
    def __init__(self, ip_manager: IPManager,
                 rate_limit=100,       # requests/giây
                 burst_limit=200,      # requests tối đa trong window
                 window_sec=1,
                 ban_threshold=500):   # requests tổng trước khi ban
        self.ip_manager    = ip_manager
        self.rate_limit    = rate_limit
        self.burst_limit   = burst_limit
        self.window_sec    = window_sec
        self.ban_threshold = ban_threshold

        # {ip: deque of timestamps}
        self.request_times  = defaultdict(lambda: deque(maxlen=10000))
        self.total_requests = defaultdict(int)
        self.blocked_ips    = {}  # {ip: block_time}
        self.stats          = {'total': 0, 'blocked': 0, 'banned_ips': 0}
        self._lock = threading.Lock()

    def check_request(self, ip: str) -> dict:
        """
        Kiểm tra request từ IP.
        Trả về {'allowed': bool, 'reason': str, 'rate': float}
        """
        with self._lock:
            self.stats['total'] += 1

            if self.ip_manager.is_blocked(ip):
                self.stats['blocked'] += 1
                return {'allowed': False, 'reason': 'IP đã bị chặn', 'rate': 0}

            now = time.time()
            window_start = now - self.window_sec
            times = self.request_times[ip]

            # Loại bỏ timestamps cũ
            while times and times[0] < window_start:
                times.popleft()

            times.append(now)
            rate = len(times) / self.window_sec
            self.total_requests[ip] += 1
            total = self.total_requests[ip]

            # Kiểm tra rate limit
            if len(times) > self.burst_limit:
                reason = f"Burst limit ({len(times)}/{self.burst_limit} req/s)"
                if total > self.ban_threshold:
                    self.ip_manager.block_ip(ip, reason)
                    self.stats['banned_ips'] += 1
                self.stats['blocked'] += 1
                return {'allowed': False, 'reason': reason, 'rate': rate}

            return {'allowed': True, 'reason': 'OK', 'rate': rate}

    def get_top_ips(self, n=10):
        """Lấy top N IP có nhiều request nhất"""
        sorted_ips = sorted(self.total_requests.items(),
                            key=lambda x: x[1], reverse=True)
        return sorted_ips[:n]

    def get_stats(self):
        return {**self.stats, 'monitored_ips': len(self.total_requests)}


# ─────────────────────────────────────────────
# PORT SCANNER DETECTOR (Chống Scan Cổng)
# ─────────────────────────────────────────────
class PortScanDetector:
    def __init__(self, ip_manager: IPManager,
                 threshold=10,   # số cổng scan trong window
                 window_sec=5):
        self.ip_manager  = ip_manager
        self.threshold   = threshold
        self.window_sec  = window_sec
        self.scan_events = defaultdict(lambda: deque(maxlen=1000))
        self._lock = threading.Lock()

    def record_connection_attempt(self, ip: str, port: int):
        """Ghi lại mỗi lần kết nối vào cổng"""
        with self._lock:
            now = time.time()
            window_start = now - self.window_sec
            events = self.scan_events[ip]
            while events and events[0][0] < window_start:
                events.popleft()
            events.append((now, port))

            unique_ports = len(set(e[1] for e in events))
            if unique_ports >= self.threshold:
                reason = f"Port scan: {unique_ports} cổng trong {self.window_sec}s"
                if self.ip_manager.block_ip(ip, reason):
                    alert = self._create_alert(ip, 'PORT_SCAN', reason)
                    self._save_alert(alert)
                    return False
        return True

    def _create_alert(self, ip, alert_type, detail):
        return {
            'time': datetime.now().isoformat(),
            'ip': ip,
            'type': alert_type,
            'detail': detail,
            'geo': self._get_geo(ip)
        }

    def _get_geo(self, ip):
        """Tra cứu vị trí IP (offline simple lookup)"""
        try:
            addr = ipaddress.ip_address(ip)
            if addr.is_private or addr.is_loopback:
                return 'Local Network'
        except Exception:
            pass
        return 'Unknown'

    def _save_alert(self, alert):
        with open(ALERT_LOG, 'a') as f:
            f.write(json.dumps(alert, ensure_ascii=False) + '\n')
        print(f"\n[!!! CẢNH BÁO !!!] {alert['type']} từ {alert['ip']}: {alert['detail']}")


# ─────────────────────────────────────────────
# NETWORK MONITOR (Giám sát kết nối thực tế)
# ─────────────────────────────────────────────
class NetworkMonitor:
    def __init__(self, ip_manager: IPManager, anti_ddos: AntiDDoS):
        self.ip_manager  = ip_manager
        self.anti_ddos   = anti_ddos
        self.port_scanner_det = PortScanDetector(ip_manager)
        self.known_connections = set()
        self.intrusion_ips     = {}   # {ip: last_seen_time}
        self.running = False
        self._lock   = threading.Lock()

    def get_current_connections(self):
        """Lấy tất cả kết nối mạng hiện tại"""
        connections = []
        if not HAS_PSUTIL:
            return connections
        for conn in psutil.net_connections(kind='inet'):
            if conn.raddr and conn.status == 'ESTABLISHED':
                connections.append({
                    'local':  f"{conn.laddr.ip}:{conn.laddr.port}",
                    'remote': f"{conn.raddr.ip}:{conn.raddr.port}",
                    'remote_ip': conn.raddr.ip,
                    'remote_port': conn.raddr.port,
                    'status': conn.status,
                    'pid': conn.pid
                })
        return connections

    def check_intrusion(self, conn_info):
        """Kiểm tra xem kết nối có phải xâm nhập không"""
        ip   = conn_info['remote_ip']
        port = conn_info['remote_port']

        # Bỏ qua IP nội bộ
        try:
            if ipaddress.ip_address(ip).is_private:
                return None
        except Exception:
            return None

        # Kiểm tra blacklist
        if self.ip_manager.is_blocked(ip):
            return {'type': 'BLACKLISTED', 'ip': ip, 'detail': 'IP trong blacklist'}

        # Kiểm tra DDoS
        result = self.anti_ddos.check_request(ip)
        if not result['allowed']:
            return {'type': 'DDOS', 'ip': ip, 'detail': result['reason']}

        # Kiểm tra port scan
        self.port_scanner_det.record_connection_attempt(ip, port)
        return None

    def scan_loop(self, interval=2):
        """Vòng lặp quét kết nối liên tục"""
        self.running = True
        print("[MONITOR] Bắt đầu giám sát mạng...")
        while self.running:
            try:
                conns = self.get_current_connections()
                for conn in conns:
                    key = (conn['remote_ip'], conn['remote_port'])
                    if key not in self.known_connections:
                        self.known_connections.add(key)
                        intrusion = self.check_intrusion(conn)
                        if intrusion:
                            self._handle_intrusion(conn, intrusion)
                        else:
                            print(f"[CONN] Kết nối mới: {conn['remote']} | PID: {conn['pid']}")
            except Exception as e:
                logging.error(f"Monitor error: {e}")
            time.sleep(interval)

    def _handle_intrusion(self, conn, intrusion):
        ip = intrusion['ip']
        with self._lock:
            self.intrusion_ips[ip] = datetime.now()

        alert = {
            'time':   datetime.now().isoformat(),
            'ip':     ip,
            'type':   intrusion['type'],
            'detail': intrusion['detail'],
            'local':  conn['local'],
            'remote': conn['remote'],
        }
        with open(ALERT_LOG, 'a') as f:
            f.write(json.dumps(alert, ensure_ascii=False) + '\n')

        print(f"\n{'='*60}")
        print(f"  !!! XÂM NHẬP PHÁT HIỆN !!!")
        print(f"  IP       : {ip}")
        print(f"  Loại     : {intrusion['type']}")
        print(f"  Chi tiết : {intrusion['detail']}")
        print(f"  Địa chỉ  : {conn['remote']}")
        print(f"  Thời gian: {alert['time']}")
        print(f"{'='*60}\n")
        logging.warning(f"INTRUSION: {json.dumps(alert)}")

    def get_intrusion_report(self):
        report = []
        for ip, last_seen in self.intrusion_ips.items():
            report.append({
                'ip': ip,
                'last_seen': last_seen.strftime('%Y-%m-%d %H:%M:%S'),
                'blocked': self.ip_manager.is_blocked(ip)
            })
        return report

    def stop(self):
        self.running = False
        print("[MONITOR] Đã dừng.")


# ─────────────────────────────────────────────
# HONEYPOT (Bẫy hacker)
# ─────────────────────────────────────────────
class Honeypot:
    """Mở các cổng giả để bắt hacker scan"""
    FAKE_PORTS = [21, 22, 23, 3306, 5432, 1433]  # FTP, SSH, Telnet, MySQL, Postgres, MSSQL

    def __init__(self, ip_manager: IPManager, port_scanner_det: PortScanDetector):
        self.ip_manager       = ip_manager
        self.port_scanner_det = port_scanner_det
        self.sockets = []
        self.running = False

    def start(self):
        self.running = True
        for port in self.FAKE_PORTS:
            t = threading.Thread(target=self._listen, args=(port,))
            t.daemon = True
            t.start()
        print(f"[HONEYPOT] Đang lắng nghe tại cổng: {self.FAKE_PORTS}")

    def _listen(self, port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind(('0.0.0.0', port))
            s.listen(5)
            self.sockets.append(s)
            while self.running:
                try:
                    s.settimeout(1)
                    conn, addr = s.accept()
                    ip = addr[0]
                    msg = f"Kết nối tới cổng honeypot {port}"
                    print(f"[HONEYPOT] {ip} kết nối cổng {port} - BỊ BẮT!")
                    logging.warning(f"HONEYPOT HIT: {ip}:{addr[1]} -> port {port}")
                    self.ip_manager.block_ip(ip, f"Honeypot trigger port {port}")
                    self.port_scanner_det.record_connection_attempt(ip, port)
                    conn.send(b"Access Denied\r\n")
                    conn.close()
                except socket.timeout:
                    continue
                except Exception:
                    pass
        except OSError as e:
            print(f"[HONEYPOT] Không mở được cổng {port}: {e}")

    def stop(self):
        self.running = False
        for s in self.sockets:
            try:
                s.close()
            except Exception:
                pass


# ─────────────────────────────────────────────
# BẢNG ĐIỀU KHIỂN CHÍNH
# ─────────────────────────────────────────────
class SecurityDashboard:
    def __init__(self):
        self.ip_manager    = IPManager()
        self.anti_ddos     = AntiDDoS(self.ip_manager)
        self.net_monitor   = NetworkMonitor(self.ip_manager, self.anti_ddos)
        self.honeypot      = Honeypot(self.ip_manager,
                                      self.net_monitor.port_scanner_det)

    def start_all(self):
        """Khởi động tất cả hệ thống bảo mật"""
        # Honeypot
        self.honeypot.start()
        # Monitor mạng (background thread)
        t = threading.Thread(target=self.net_monitor.scan_loop)
        t.daemon = True
        t.start()
        print("\n[SECURITY] Tất cả hệ thống bảo mật đã khởi động.")
        self._interactive_console()

    def _interactive_console(self):
        """Console tương tác"""
        while True:
            print("\n" + "─"*50)
            print("  HỆ THỐNG BẢO MẬT - BẢNG ĐIỀU KHIỂN")
            print("─"*50)
            print("  1. Xem kết nối hiện tại")
            print("  2. Xem IP xâm nhập")
            print("  3. Thống kê Anti-DDoS")
            print("  4. Chặn IP thủ công")
            print("  5. Bỏ chặn IP")
            print("  6. Xem blacklist")
            print("  7. Xem log cảnh báo")
            print("  0. Thoát")
            print("─"*50)
            choice = input("  Chọn: ").strip()

            if choice == '1':
                conns = self.net_monitor.get_current_connections()
                print(f"\n  Kết nối đang hoạt động ({len(conns)}):")
                for c in conns:
                    print(f"    {c['local']} <-> {c['remote']} | PID:{c['pid']}")

            elif choice == '2':
                report = self.net_monitor.get_intrusion_report()
                print(f"\n  IP Xâm nhập ({len(report)}):")
                for r in report:
                    blocked = "ĐÃ CHẶN" if r['blocked'] else "CHƯA CHẶN"
                    print(f"    {r['ip']} | {r['last_seen']} | {blocked}")

            elif choice == '3':
                stats = self.anti_ddos.get_stats()
                print(f"\n  Thống kê Anti-DDoS:")
                for k, v in stats.items():
                    print(f"    {k}: {v}")
                print("\n  Top IP nhiều request nhất:")
                for ip, count in self.anti_ddos.get_top_ips(5):
                    print(f"    {ip}: {count} requests")

            elif choice == '4':
                ip = input("  Nhập IP cần chặn: ").strip()
                reason = input("  Lý do: ").strip()
                self.ip_manager.block_ip(ip, reason)

            elif choice == '5':
                ip = input("  Nhập IP cần bỏ chặn: ").strip()
                self.ip_manager.unblock_ip(ip)

            elif choice == '6':
                bl = self.ip_manager.blacklist
                print(f"\n  Blacklist ({len(bl)} IP):")
                for ip in bl:
                    print(f"    {ip}")

            elif choice == '7':
                if os.path.exists(ALERT_LOG):
                    with open(ALERT_LOG) as f:
                        lines = f.readlines()
                    print(f"\n  Cảnh báo gần nhất (20 dòng):")
                    for line in lines[-20:]:
                        try:
                            a = json.loads(line)
                            print(f"    [{a['time']}] {a['type']} - {a['ip']}: {a['detail']}")
                        except Exception:
                            print(f"    {line.strip()}")
                else:
                    print("  Chưa có cảnh báo nào.")

            elif choice == '0':
                self.net_monitor.stop()
                self.honeypot.stop()
                print("  Đã dừng hệ thống bảo mật.")
                break


# ─────────────────────────────────────────────
if __name__ == '__main__':
    dashboard = SecurityDashboard()
    dashboard.start_all()
