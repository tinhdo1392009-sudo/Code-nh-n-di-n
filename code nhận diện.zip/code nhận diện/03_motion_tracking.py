"""
MODULE 3: NHẬN DIỆN VẬT THỂ DI CHUYỂN + CAMERA THEO DÕI
Thư viện: pip install opencv-python numpy
Tùy chọn: pip install pyserial (điều khiển servo/pan-tilt)
"""

import cv2
import numpy as np
import threading
import time
import logging
from datetime import datetime
import os

logging.basicConfig(filename='motion_tracking.log', level=logging.INFO,
                    format='%(asctime)s - %(message)s')

ALERT_DIR = 'motion_alerts'
os.makedirs(ALERT_DIR, exist_ok=True)


# ─────────────────────────────────────────────
# PHÁT HIỆN CHUYỂN ĐỘNG (Background Subtraction)
# ─────────────────────────────────────────────
class MotionDetector:
    def __init__(self, sensitivity=500, blur_size=21):
        self.sensitivity  = sensitivity   # Diện tích tối thiểu để coi là chuyển động
        self.blur_size    = blur_size
        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=50, detectShadows=True)
        self.first_frame  = None
        self.motion_count = 0

    def detect(self, frame):
        """
        Trả về: (has_motion: bool, contours, fg_mask)
        """
        gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (self.blur_size, self.blur_size), 0)

        fg_mask = self.bg_subtractor.apply(blurred)
        # Loại bỏ bóng (giá trị 127)
        _, fg_mask = cv2.threshold(fg_mask, 200, 255, cv2.THRESH_BINARY)
        # Làm sạch mask
        kernel   = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        fg_mask  = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN,  kernel)
        fg_mask  = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)

        contours, _ = cv2.findContours(
            fg_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        significant = [c for c in contours if cv2.contourArea(c) > self.sensitivity]
        has_motion = len(significant) > 0
        if has_motion:
            self.motion_count += 1
        return has_motion, significant, fg_mask

    def get_bounding_boxes(self, contours):
        """Lấy bounding box từ contours"""
        boxes = []
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            cx = x + w // 2
            cy = y + h // 2
            area = cv2.contourArea(c)
            boxes.append({'x': x, 'y': y, 'w': w, 'h': h,
                          'cx': cx, 'cy': cy, 'area': area})
        return boxes


# ─────────────────────────────────────────────
# PHÁT HIỆN VẬT THỂ (YOLO / HOG)
# ─────────────────────────────────────────────
class ObjectDetector:
    def __init__(self, method='hog'):
        """
        method: 'hog' (không cần model), 'yolo' (cần weights)
        """
        self.method = method
        if method == 'hog':
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        elif method == 'yolo':
            self._load_yolo()

    def _load_yolo(self):
        """Tải YOLO model (cần download weights)"""
        weights = 'yolov4-tiny.weights'
        config  = 'yolov4-tiny.cfg'
        names   = 'coco.names'
        if not os.path.exists(weights):
            print("[!] Cần download yolov4-tiny.weights và yolov4-tiny.cfg")
            print("    wget https://github.com/AlexeyAB/darknet/releases/download/darknet_yolo_v4_pre/yolov4-tiny.weights")
            self.method = 'hog'
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
            return
        self.net    = cv2.dnn.readNet(weights, config)
        self.classes = open(names).read().strip().split('\n') if os.path.exists(names) else []
        layer_names  = self.net.getLayerNames()
        self.output_layers = [
            layer_names[i - 1]
            for i in self.net.getUnconnectedOutLayers().flatten()]

    def detect(self, frame):
        """Trả về list {'label', 'confidence', 'box': (x,y,w,h), 'cx', 'cy'}"""
        if self.method == 'hog':
            return self._detect_hog(frame)
        elif self.method == 'yolo':
            return self._detect_yolo(frame)
        return []

    def _detect_hog(self, frame):
        results = []
        boxes, weights = self.hog.detectMultiScale(
            frame, winStride=(8,8), padding=(4,4), scale=1.05)
        for (x, y, w, h), conf in zip(boxes, weights):
            results.append({'label': 'Person', 'confidence': float(conf),
                            'box': (x,y,w,h),
                            'cx': x + w//2, 'cy': y + h//2})
        return results

    def _detect_yolo(self, frame):
        results = []
        h, w = frame.shape[:2]
        blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416,416), swapRB=True, crop=False)
        self.net.setInput(blob)
        outs = self.net.forward(self.output_layers)

        class_ids, confs, boxes = [], [], []
        for out in outs:
            for det in out:
                scores = det[5:]
                cid    = np.argmax(scores)
                conf   = scores[cid]
                if conf > 0.5:
                    cx, cy = int(det[0]*w), int(det[1]*h)
                    bw, bh = int(det[2]*w), int(det[3]*h)
                    x, y   = cx - bw//2, cy - bh//2
                    class_ids.append(cid)
                    confs.append(float(conf))
                    boxes.append([x, y, bw, bh])

        indices = cv2.dnn.NMSBoxes(boxes, confs, 0.5, 0.4)
        if len(indices) > 0:
            for i in indices.flatten():
                x,y,bw,bh = boxes[i]
                label = self.classes[class_ids[i]] if class_ids[i] < len(self.classes) else str(class_ids[i])
                results.append({'label': label, 'confidence': confs[i],
                                'box': (x,y,bw,bh),
                                'cx': x+bw//2, 'cy': y+bh//2})
        return results


# ─────────────────────────────────────────────
# CAMERA THEO DÕI (Pan-Tilt Controller)
# ─────────────────────────────────────────────
class PanTiltController:
    """
    Điều khiển camera servo pan-tilt qua serial (Arduino/Raspberry Pi)
    hoặc mô phỏng trên màn hình.
    """
    def __init__(self, serial_port=None, baud=9600, frame_w=640, frame_h=480):
        self.frame_w   = frame_w
        self.frame_h   = frame_h
        self.center_x  = frame_w // 2
        self.center_y  = frame_h // 2
        self.pan_angle  = 90  # Góc ban đầu (0-180)
        self.tilt_angle = 90
        self.serial     = None
        self.dead_zone  = 30  # Pixel dead-zone trước khi di chuyển

        if serial_port:
            try:
                import serial
                self.serial = serial.Serial(serial_port, baud, timeout=1)
                time.sleep(2)
                print(f"[PAN-TILT] Đã kết nối serial: {serial_port}")
            except Exception as e:
                print(f"[PAN-TILT] Không kết nối được serial: {e}")

    def track(self, target_cx, target_cy):
        """
        Di chuyển camera về phía target (cx, cy).
        Trả về (pan_delta, tilt_delta)
        """
        err_x = target_cx - self.center_x
        err_y = target_cy - self.center_y

        pan_delta  = 0
        tilt_delta = 0

        # Proportional control
        if abs(err_x) > self.dead_zone:
            pan_delta  = int(err_x * 0.05)
            self.pan_angle  = max(0, min(180, self.pan_angle  + pan_delta))

        if abs(err_y) > self.dead_zone:
            tilt_delta = int(err_y * 0.05)
            self.tilt_angle = max(0, min(180, self.tilt_angle + tilt_delta))

        if self.serial and (pan_delta or tilt_delta):
            cmd = f"P{self.pan_angle}T{self.tilt_angle}\n"
            self.serial.write(cmd.encode())

        return pan_delta, tilt_delta

    def get_status(self):
        return {'pan': self.pan_angle, 'tilt': self.tilt_angle}


# ─────────────────────────────────────────────
# HỆ THỐNG TỔNG HỢP: THEO DÕI + PHÁT HIỆN
# ─────────────────────────────────────────────
class TrackingSystem:
    def __init__(self, camera_index=0, detect_method='hog',
                 serial_port=None, save_alerts=True):
        self.cap           = cv2.VideoCapture(camera_index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.motion_det    = MotionDetector()
        self.obj_det       = ObjectDetector(method=detect_method)
        self.pan_tilt      = PanTiltController(serial_port=serial_port)
        self.save_alerts   = save_alerts
        self.alert_count   = 0
        self.target_lock   = None   # Vật thể đang theo dõi
        self.tracking_on   = True

    def _save_alert(self, frame):
        """Lưu ảnh cảnh báo"""
        ts   = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        path = os.path.join(ALERT_DIR, f'alert_{ts}.jpg')
        cv2.imwrite(path, frame)
        self.alert_count += 1
        logging.info(f"Cảnh báo #{self.alert_count}: {path}")

    def _draw_crosshair(self, frame, cx, cy, color=(0,255,255)):
        cv2.line(frame, (cx-20, cy), (cx+20, cy), color, 2)
        cv2.line(frame, (cx, cy-20), (cx, cy+20), color, 2)
        cv2.circle(frame, (cx, cy), 8, color, 2)

    def run(self):
        print("[TRACKING] Bắt đầu. Phím: Q=thoát, T=bật/tắt theo dõi, R=reset target")
        fps_time = time.time()
        frame_count = 0

        while True:
            ret, frame = self.cap.read()
            if not ret:
                break

            frame_count += 1
            h, w = frame.shape[:2]

            # ── Phát hiện chuyển động ──
            has_motion, contours, fg_mask = self.motion_det.detect(frame)
            boxes = self.motion_det.get_bounding_boxes(contours)

            # ── Phát hiện vật thể (mỗi 5 frame để giảm tải) ──
            objects = []
            if frame_count % 5 == 0:
                objects = self.obj_det.detect(frame)

            # ── Vẽ chuyển động ──
            for box in boxes:
                cv2.rectangle(frame,
                    (box['x'], box['y']),
                    (box['x']+box['w'], box['y']+box['h']),
                    (0, 255, 0), 1)

            # ── Vẽ vật thể ──
            for obj in objects:
                x, y, bw, bh = obj['box']
                label = f"{obj['label']} {obj['confidence']:.0%}"
                cv2.rectangle(frame, (x,y), (x+bw,y+bh), (255,165,0), 2)
                cv2.putText(frame, label, (x, y-5),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,165,0), 1)

            # ── Theo dõi vật thể lớn nhất ──
            if self.tracking_on and boxes:
                biggest = max(boxes, key=lambda b: b['area'])
                target_cx = biggest['cx']
                target_cy = biggest['cy']
                self._draw_crosshair(frame, target_cx, target_cy)

                pan_d, tilt_d = self.pan_tilt.track(target_cx, target_cy)
                status = self.pan_tilt.get_status()
                cv2.putText(frame,
                    f"Pan:{status['pan']}  Tilt:{status['tilt']}",
                    (10, h-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,255), 1)

                # Lưu cảnh báo khi phát hiện chuyển động
                if has_motion and self.save_alerts and frame_count % 30 == 0:
                    self._save_alert(frame)

            # ── HUD ──
            fps = frame_count / max(time.time() - fps_time, 0.001)
            status_text = f"FPS:{fps:.1f} | Chuyen dong: {'CO' if has_motion else 'KHONG'}"
            status_text += f" | Vat the: {len(objects)} | Canh bao: {self.alert_count}"
            tracking_str = "Theo doi: BAT" if self.tracking_on else "Theo doi: TAT"
            cv2.putText(frame, status_text, (10, 25),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)
            cv2.putText(frame, tracking_str, (10, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        (0,255,0) if self.tracking_on else (0,0,255), 1)

            # Vẽ center crosshair
            cv2.line(frame, (w//2-15, h//2), (w//2+15, h//2), (128,128,128), 1)
            cv2.line(frame, (w//2, h//2-15), (w//2, h//2+15), (128,128,128), 1)

            cv2.imshow('He Thong Theo Doi Vat The', frame)
            # Hiện mask chuyển động
            cv2.imshow('Chuyen Dong Mask', fg_mask)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('t'):
                self.tracking_on = not self.tracking_on
                print(f"[TRACKING] {'BẬT' if self.tracking_on else 'TẮT'}")
            elif key == ord('r'):
                self.target_lock = None
                print("[TRACKING] Reset target")

        self.cap.release()
        cv2.destroyAllWindows()
        print(f"[TRACKING] Kết thúc. Tổng cảnh báo: {self.alert_count}")


# ─────────────────────────────────────────────
if __name__ == '__main__':
    system = TrackingSystem(
        camera_index=0,
        detect_method='hog',   # 'hog' hoặc 'yolo'
        serial_port=None,      # Ví dụ: 'COM3' hoặc '/dev/ttyUSB0'
        save_alerts=True
    )
    system.run()
