"""
MODULE 2: NHẬN DIỆN KHUÔN MẶT (Face Recognition)
Thư viện: pip install opencv-python face-recognition numpy
"""

import cv2
import numpy as np
import os
import json
import time
from datetime import datetime
import logging

logging.basicConfig(filename='face_recognition.log', level=logging.INFO,
                    format='%(asctime)s - %(message)s')

KNOWN_FACES_DIR = 'known_faces'
FACE_DATA_FILE  = 'face_data.json'
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)


class FaceRecognitionSystem:
    def __init__(self):
        self.known_face_encodings = []
        self.known_face_names = []
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        self.recognition_log = []
        self.load_known_faces()

    # ──────────────────────────────────────────
    # Tải khuôn mặt đã biết
    # ──────────────────────────────────────────
    def load_known_faces(self):
        """Tải dữ liệu khuôn mặt từ thư mục"""
        try:
            import face_recognition
            self.known_face_encodings = []
            self.known_face_names = []
            for filename in os.listdir(KNOWN_FACES_DIR):
                if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
                    path = os.path.join(KNOWN_FACES_DIR, filename)
                    image = face_recognition.load_image_file(path)
                    encodings = face_recognition.face_encodings(image)
                    if encodings:
                        self.known_face_encodings.append(encodings[0])
                        name = os.path.splitext(filename)[0]
                        self.known_face_names.append(name)
                        print(f"[+] Đã tải khuôn mặt: {name}")
            print(f"Tổng cộng {len(self.known_face_names)} khuôn mặt đã biết.")
        except ImportError:
            print("[!] face_recognition chưa cài. Dùng chế độ OpenCV Haar Cascade.")

    # ──────────────────────────────────────────
    # Đăng ký khuôn mặt mới
    # ──────────────────────────────────────────
    def register_face(self, name: str, image_path: str = None):
        """Đăng ký khuôn mặt từ webcam hoặc file ảnh"""
        try:
            import face_recognition
            if image_path:
                image = face_recognition.load_image_file(image_path)
            else:
                cap = cv2.VideoCapture(0)
                print("Nhìn vào camera. Nhấn SPACE để chụp, Q để thoát.")
                captured = None
                while True:
                    ret, frame = cap.read()
                    if not ret:
                        break
                    cv2.imshow('Đăng ký khuôn mặt - Nhấn SPACE để chụp', frame)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord(' '):
                        captured = frame
                        break
                    elif key == ord('q'):
                        break
                cap.release()
                cv2.destroyAllWindows()
                if captured is None:
                    return False
                image = cv2.cvtColor(captured, cv2.COLOR_BGR2RGB)

            encodings = face_recognition.face_encodings(image)
            if not encodings:
                print("[-] Không tìm thấy khuôn mặt trong ảnh!")
                return False

            # Lưu ảnh
            save_path = os.path.join(KNOWN_FACES_DIR, f'{name}.jpg')
            if image_path:
                import shutil
                shutil.copy(image_path, save_path)
            else:
                cv2.imwrite(save_path, cv2.cvtColor(image, cv2.COLOR_RGB2BGR))

            self.known_face_encodings.append(encodings[0])
            self.known_face_names.append(name)
            print(f"[+] Đã đăng ký khuôn mặt: {name}")
            logging.info(f"Đăng ký khuôn mặt mới: {name}")
            return True

        except ImportError:
            print("[!] face_recognition chưa cài.")
            return False

    # ──────────────────────────────────────────
    # Nhận diện khuôn mặt từ webcam
    # ──────────────────────────────────────────
    def recognize_from_camera(self, camera_index=0, callback=None):
        """
        Nhận diện khuôn mặt realtime từ webcam.
        callback(name, frame, location): gọi mỗi khi nhận diện được.
        """
        cap = cv2.VideoCapture(camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        print("[FACE] Bắt đầu nhận diện khuôn mặt. Nhấn Q để thoát.")
        frame_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame_count += 1
            # Xử lý mỗi 2 frame để giảm tải
            if frame_count % 2 == 0:
                small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
                rgb_small = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
                detected = self._detect_and_recognize(rgb_small, frame)

                for (name, (top, right, bottom, left)) in detected:
                    top *= 2; right *= 2; bottom *= 2; left *= 2
                    color = (0, 255, 0) if name != "Không rõ" else (0, 0, 255)
                    cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                    cv2.rectangle(frame, (left, bottom - 30), (right, bottom), color, cv2.FILLED)
                    cv2.putText(frame, name, (left + 6, bottom - 6),
                                cv2.FONT_HERSHEY_DUPLEX, 0.7, (255, 255, 255), 1)
                    if callback:
                        callback(name, frame, (top, right, bottom, left))
                    self._log_detection(name)

            # FPS
            cv2.putText(frame, f"Khuon mat: Dang nhan dien...",
                        (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            cv2.imshow('Nhan Dien Khuon Mat', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

    def _detect_and_recognize(self, rgb_frame, original_frame):
        results = []
        try:
            import face_recognition
            locations = face_recognition.face_locations(rgb_frame)
            encodings = face_recognition.face_encodings(rgb_frame, locations)
            for enc, loc in zip(encodings, locations):
                matches = face_recognition.compare_faces(
                    self.known_face_encodings, enc, tolerance=0.5)
                name = "Không rõ"
                if True in matches:
                    distances = face_recognition.face_distance(
                        self.known_face_encodings, enc)
                    best = np.argmin(distances)
                    if matches[best]:
                        conf = (1 - distances[best]) * 100
                        name = f"{self.known_face_names[best]} ({conf:.0f}%)"
                results.append((name, loc))
        except ImportError:
            # Fallback: Haar Cascade (không nhận diện được tên)
            gray = cv2.cvtColor(original_frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 5)
            for (x, y, w, h) in faces:
                results.append(("Phát hiện", (y, x+w, y+h, x)))
        return results

    def _log_detection(self, name):
        entry = {'time': datetime.now().isoformat(), 'name': name}
        self.recognition_log.append(entry)
        if name != "Không rõ":
            logging.info(f"Nhận diện: {name}")

    def get_recognition_report(self):
        report = {}
        for entry in self.recognition_log:
            report[entry['name']] = report.get(entry['name'], 0) + 1
        return report

    # ──────────────────────────────────────────
    # Nhận diện từ file ảnh
    # ──────────────────────────────────────────
    def recognize_from_image(self, image_path):
        try:
            import face_recognition
            image = face_recognition.load_image_file(image_path)
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) if len(image.shape) == 3 else image
            results = self._detect_and_recognize(rgb, image)
            return results
        except Exception as e:
            print(f"Lỗi: {e}")
            return []


# ─────────────────────────────────────────────
# CHẠY
# ─────────────────────────────────────────────
if __name__ == '__main__':
    system = FaceRecognitionSystem()
    print("\n=== HỆ THỐNG NHẬN DIỆN KHUÔN MẶT ===")
    print("1. Đăng ký khuôn mặt mới")
    print("2. Nhận diện từ webcam")
    print("3. Nhận diện từ ảnh")

    choice = input("Chọn: ").strip()
    if choice == '1':
        name = input("Nhập tên: ").strip()
        system.register_face(name)
    elif choice == '2':
        system.recognize_from_camera()
    elif choice == '3':
        path = input("Đường dẫn ảnh: ").strip()
        results = system.recognize_from_image(path)
        for name, loc in results:
            print(f"  -> {name} tại vị trí {loc}")
