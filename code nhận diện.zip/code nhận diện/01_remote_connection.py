"""
MODULE 1: KẾT NỐI PC SANG MÁY TÍNH (Remote Connection)
Thư viện cần: pip install pyautogui pillow paramiko cryptography
"""

import socket
import threading
import pickle
import struct
import time
import logging
from datetime import datetime
import hashlib
import os

# Cấu hình
HOST = '0.0.0.0'
PORT = 9999
SECRET_KEY = hashlib.sha256(b'your_secret_key_here').hexdigest()

logging.basicConfig(
    filename='remote_connection.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# ─────────────────────────────────────────────
# SERVER (Máy bị điều khiển)
# ─────────────────────────────────────────────
class RemoteServer:
    def __init__(self, host=HOST, port=PORT):
        self.host = host
        self.port = port
        self.server_socket = None
        self.clients = {}
        self.running = False

    def authenticate_client(self, conn):
        """Xác thực client bằng secret key"""
        try:
            conn.settimeout(10)
            client_key = conn.recv(1024).decode()
            if client_key == SECRET_KEY:
                conn.send(b'AUTH_OK')
                return True
            else:
                conn.send(b'AUTH_FAIL')
                return False
        except Exception as e:
            logging.error(f"Auth error: {e}")
            return False

    def capture_screen(self):
        """Chụp màn hình và gửi cho client"""
        try:
            import pyautogui
            from PIL import Image
            import io
            screenshot = pyautogui.screenshot()
            img_bytes = io.BytesIO()
            screenshot.save(img_bytes, format='JPEG', quality=50)
            return img_bytes.getvalue()
        except ImportError:
            logging.warning("pyautogui/PIL không được cài. Dùng mock data.")
            return b''

    def handle_client(self, conn, addr):
        """Xử lý từng client kết nối"""
        ip = addr[0]
        logging.info(f"Client kết nối: {ip}:{addr[1]}")
        print(f"[+] Client kết nối: {ip}:{addr[1]}")

        if not self.authenticate_client(conn):
            logging.warning(f"Xác thực thất bại từ {ip}")
            print(f"[-] Xác thực thất bại từ {ip}")
            conn.close()
            return

        self.clients[ip] = {'conn': conn, 'connected_at': datetime.now()}

        try:
            while self.running:
                # Nhận lệnh từ client
                data = conn.recv(4096)
                if not data:
                    break

                command = pickle.loads(data)
                cmd_type = command.get('type')

                if cmd_type == 'SCREENSHOT':
                    screen_data = self.capture_screen()
                    size = struct.pack('!I', len(screen_data))
                    conn.sendall(size + screen_data)

                elif cmd_type == 'MOUSE_MOVE':
                    try:
                        import pyautogui
                        pyautogui.moveTo(command['x'], command['y'])
                    except ImportError:
                        pass

                elif cmd_type == 'MOUSE_CLICK':
                    try:
                        import pyautogui
                        pyautogui.click(command['x'], command['y'])
                    except ImportError:
                        pass

                elif cmd_type == 'KEY_PRESS':
                    try:
                        import pyautogui
                        pyautogui.press(command['key'])
                    except ImportError:
                        pass

                elif cmd_type == 'PING':
                    conn.send(pickle.dumps({'type': 'PONG', 'time': time.time()}))

        except Exception as e:
            logging.error(f"Lỗi xử lý client {ip}: {e}")
        finally:
            self.clients.pop(ip, None)
            conn.close()
            print(f"[-] Client ngắt kết nối: {ip}")
            logging.info(f"Client ngắt kết nối: {ip}")

    def start(self):
        """Khởi động server"""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(5)
        self.running = True
        print(f"[SERVER] Đang lắng nghe tại {self.host}:{self.port}")
        logging.info(f"Server khởi động tại {self.host}:{self.port}")

        while self.running:
            try:
                conn, addr = self.server_socket.accept()
                t = threading.Thread(target=self.handle_client, args=(conn, addr))
                t.daemon = True
                t.start()
            except Exception as e:
                if self.running:
                    logging.error(f"Server accept error: {e}")

    def stop(self):
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        print("[SERVER] Đã dừng.")


# ─────────────────────────────────────────────
# CLIENT (Máy điều khiển)
# ─────────────────────────────────────────────
class RemoteClient:
    def __init__(self, server_ip, port=PORT):
        self.server_ip = server_ip
        self.port = port
        self.sock = None
        self.connected = False

    def connect(self):
        """Kết nối tới server"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.server_ip, self.port))
            # Gửi secret key
            self.sock.send(SECRET_KEY.encode())
            response = self.sock.recv(1024)
            if response == b'AUTH_OK':
                self.connected = True
                print(f"[CLIENT] Kết nối thành công tới {self.server_ip}:{self.port}")
                return True
            else:
                print("[CLIENT] Xác thực thất bại!")
                return False
        except Exception as e:
            print(f"[CLIENT] Lỗi kết nối: {e}")
            return False

    def send_command(self, command_dict):
        """Gửi lệnh tới server"""
        if not self.connected:
            return None
        try:
            data = pickle.dumps(command_dict)
            self.sock.sendall(data)
            return True
        except Exception as e:
            print(f"[CLIENT] Lỗi gửi lệnh: {e}")
            self.connected = False
            return False

    def get_screenshot(self):
        """Nhận ảnh màn hình từ server"""
        self.send_command({'type': 'SCREENSHOT'})
        try:
            raw_size = self.sock.recv(4)
            size = struct.unpack('!I', raw_size)[0]
            data = b''
            while len(data) < size:
                chunk = self.sock.recv(min(4096, size - len(data)))
                if not chunk:
                    break
                data += chunk
            return data
        except Exception as e:
            print(f"[CLIENT] Lỗi nhận screenshot: {e}")
            return None

    def disconnect(self):
        if self.sock:
            self.sock.close()
        self.connected = False
        print("[CLIENT] Đã ngắt kết nối.")


# ─────────────────────────────────────────────
# CHẠY
# ─────────────────────────────────────────────
if __name__ == '__main__':
    import sys
    mode = input("Chọn chế độ (server/client): ").strip().lower()

    if mode == 'server':
        srv = RemoteServer()
        try:
            srv.start()
        except KeyboardInterrupt:
            srv.stop()

    elif mode == 'client':
        ip = input("Nhập IP server: ").strip()
        cli = RemoteClient(ip)
        if cli.connect():
            while True:
                cmd = input("Lệnh (screenshot/move/click/quit): ").strip()
                if cmd == 'screenshot':
                    data = cli.get_screenshot()
                    if data:
                        with open('screenshot.jpg', 'wb') as f:
                            f.write(data)
                        print("Đã lưu screenshot.jpg")
                elif cmd == 'quit':
                    cli.disconnect()
                    break
