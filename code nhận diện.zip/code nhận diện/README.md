# HỆ THỐNG GIÁM SÁT & BẢO MẬT TOÀN DIỆN - Python

## Cấu trúc Module

| File | Mô tả |
|------|-------|
| `01_remote_connection.py` | Kết nối từ xa PC sang máy tính |
| `02_face_recognition.py` | Nhận diện khuôn mặt qua webcam |
| `03_motion_tracking.py` | Phát hiện vật thể + camera theo dõi |
| `04_security_system.py` | Anti-DDoS + IDS + Honeypot + IP xâm nhập |
| `05_main_launcher.py` | Menu khởi chạy tất cả module |

---

## Cài thư viện

```bash
# Cơ bản
pip install opencv-python numpy psutil pillow requests pyautogui

# Nhận diện khuôn mặt (cần dlib)
pip install face-recognition

# Điều khiển servo camera
pip install pyserial

# Remote desktop
pip install paramiko
```

---

## Hướng dẫn từng Module

### MODULE 1 - Remote Connection
```bash
python 01_remote_connection.py
# Chọn: server (máy bị điều khiển) hoặc client (máy điều khiển)
```
- Server: lắng nghe kết nối, xác thực bằng secret key, nhận lệnh điều khiển
- Client: kết nối, chụp màn hình, điều khiển chuột/bàn phím

### MODULE 2 - Face Recognition
```bash
python 02_face_recognition.py
# 1. Đăng ký khuôn mặt → chụp từ webcam → lưu vào known_faces/
# 2. Nhận diện realtime từ webcam
# 3. Nhận diện từ file ảnh
```
- Dùng `face_recognition` nếu cài được, fallback sang Haar Cascade
- Log nhận diện lưu vào `face_recognition.log`

### MODULE 3 - Motion Tracking
```bash
python 03_motion_tracking.py
# Phím: Q=thoát, T=bật/tắt theo dõi, R=reset target
```
- Background subtraction (MOG2) phát hiện chuyển động
- HOG hoặc YOLO nhận diện loại vật thể
- Pan-Tilt servo tự động xoay camera theo vật thể lớn nhất
- Lưu ảnh cảnh báo vào `motion_alerts/`

### MODULE 4 - Security System
```bash
# Cần quyền Administrator/root để chặn firewall
python 04_security_system.py
```
**Tính năng:**
- **Anti-DDoS**: Giới hạn rate 100 req/s, ban tự động khi vượt ngưỡng
- **Port Scan Detection**: Phát hiện scan >10 cổng trong 5 giây
- **Honeypot**: Mở cổng giả (21,22,23,3306...) bẫy hacker
- **Network Monitor**: Quét kết nối mạng mỗi 2 giây
- **IP Manager**: Whitelist/Blacklist + chặn qua firewall hệ thống
- **Hiện IP xâm nhập**: Log + báo cáo real-time

---

## Cấu hình

Chỉnh sửa các biến trong đầu mỗi file:

```python
# 01_remote_connection.py
PORT = 9999
SECRET_KEY = 'your_key_here'

# 03_motion_tracking.py
sensitivity = 500   # Nhạy cảm chuyển động
detect_method = 'hog'  # 'hog' hoặc 'yolo'
serial_port = None  # 'COM3' hoặc '/dev/ttyUSB0'

# 04_security_system.py
rate_limit = 100     # req/s trước khi cảnh báo
ban_threshold = 500  # tổng req trước khi ban IP
```

---

## Yêu cầu hệ thống
- Python 3.8+
- Webcam (module 2, 3)
- Quyền Admin (module 4 - để chặn firewall)
- Arduino/Servo (tùy chọn - module 3 pan-tilt)
