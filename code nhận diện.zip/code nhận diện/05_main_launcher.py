"""
MODULE 5: MAIN LAUNCHER - Khởi chạy tất cả hệ thống
Cài tất cả thư viện: pip install opencv-python face-recognition numpy psutil pyserial requests
"""

import subprocess
import sys
import os
import threading


REQUIREMENTS = [
    'opencv-python',
    'numpy',
    'psutil',
    'pillow',
    'requests',
]

OPTIONAL_REQUIREMENTS = [
    'face-recognition',   # Cần dlib, có thể khó cài trên Windows
    'pyserial',           # Điều khiển servo
    'scapy',              # Bắt gói tin mạng sâu hơn
    'pyautogui',          # Remote desktop
    'paramiko',           # SSH
]


def install_requirements():
    print("Đang cài thư viện cần thiết...")
    for pkg in REQUIREMENTS:
        subprocess.run([sys.executable, '-m', 'pip', 'install', pkg, '-q'])
        print(f"  ✓ {pkg}")
    print("\nThư viện tùy chọn (cài thủ công nếu cần):")
    for pkg in OPTIONAL_REQUIREMENTS:
        print(f"  pip install {pkg}")


def run_remote_server():
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("remote", "01_remote_connection.py")
    mod  = module_from_spec(spec)
    spec.loader.exec_module(mod)
    srv = mod.RemoteServer()
    srv.start()


def run_face_recognition():
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("face", "02_face_recognition.py")
    mod  = module_from_spec(spec)
    spec.loader.exec_module(mod)
    system = mod.FaceRecognitionSystem()
    system.recognize_from_camera()


def run_tracking():
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("tracking", "03_motion_tracking.py")
    mod  = module_from_spec(spec)
    spec.loader.exec_module(mod)
    system = mod.TrackingSystem()
    system.run()


def run_security():
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("security", "04_security_system.py")
    mod  = module_from_spec(spec)
    spec.loader.exec_module(mod)
    dashboard = mod.SecurityDashboard()
    dashboard.start_all()


MENU = {
    '1': ('Kết nối Remote (Server)',         run_remote_server),
    '2': ('Nhận diện khuôn mặt (Webcam)',    run_face_recognition),
    '3': ('Phát hiện & Theo dõi vật thể',    run_tracking),
    '4': ('Hệ thống bảo mật (Anti-DDoS + IDS)', run_security),
    '5': ('Cài thư viện',                    install_requirements),
}


def main():
    print("""
╔══════════════════════════════════════════════════════╗
║      HỆ THỐNG GIÁM SÁT & BẢO MẬT TOÀN DIỆN         ║
║                   Python Edition                     ║
╠══════════════════════════════════════════════════════╣
║  Các module:                                         ║
║  01_remote_connection.py  - Kết nối từ xa            ║
║  02_face_recognition.py   - Nhận diện khuôn mặt      ║
║  03_motion_tracking.py    - Theo dõi vật thể          ║
║  04_security_system.py    - Anti-DDoS / IDS           ║
╚══════════════════════════════════════════════════════╝
""")

    while True:
        print("\n─── MENU CHÍNH ───")
        for key, (label, _) in MENU.items():
            print(f"  {key}. {label}")
        print("  0. Thoát")

        choice = input("\nChọn: ").strip()
        if choice == '0':
            print("Tạm biệt!")
            break
        elif choice in MENU:
            label, func = MENU[choice]
            print(f"\n[*] Khởi chạy: {label}\n")
            try:
                func()
            except ImportError as e:
                print(f"[LỖI] Thiếu thư viện: {e}")
                print("Chạy mục 5 để cài thư viện.")
            except KeyboardInterrupt:
                print("\n[*] Đã dừng module.")
        else:
            print("Lựa chọn không hợp lệ.")


if __name__ == '__main__':
    main()
